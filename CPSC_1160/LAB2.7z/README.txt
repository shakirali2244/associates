A) filling array with values from 0 to 12


B) largest number that can be produced is given by RAND_MAX from namespace cstdlib which happens to be 32767
you use unsigned version of int to do so since int can store upto 2^16 -1 

C) not enough time