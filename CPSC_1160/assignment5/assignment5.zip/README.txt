6) Yes my plots match the theory of the big O notations. the S(n) is an exponential curve and Q(n) and M(n) 
are n log2n curves. Those values in 3rd 5th and 7th columns are those constants because we are essentially dividing
k*n^2/n^2 for S(n) and k*nlogn/nlogn for Q(n) and M(n) and those numbers are those k. That also means that 
that is the average time taken by those algorithms to sort hence becoming the average case.

Is last part a question?? Why is it at the end.